# ogam_bot

Bot for http://ogam.net.pl/

### config
create your own config.py:

```
ACCOUNT_DATA = {
    "login": " ",
    "password": " ",
    "uni_url": "http://uni10.ogam.net.pl/"
}
```

### starting bot

```pip install -r requiremenets.txt```

```python bot.py```
