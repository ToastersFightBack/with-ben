import requests


class Game:
    SESSION = requests.session()
    BASE_URL = ""
    SESSION_ID = ""
    HOMEWORLD = ""
    WORLDS = {}
    COORDS = {}
