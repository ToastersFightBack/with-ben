from common.browser import Browser
from game import Game
from urls import Url
import re


class Overview:
    @staticmethod
    def planets_under_attack():
        response = Browser.go_to(Url.overview(Game.HOMEWORLD)).text
        regex_planets = re.findall(
            "(?<=planetę).*\n\t*.*\n\t*.*\n\t.*(?=Napadaj)", response
        )
        return [
            Game.COORDS.get(re.search("\[.*\]", planet)[0]) for planet in regex_planets
        ]
