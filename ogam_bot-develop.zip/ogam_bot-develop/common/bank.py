from common.browser import Browser
from game import Game
from urls import Url
import re


class Bank:
    @staticmethod
    def deposit(planet, metal, crystal, deuterium):
        data = {
            "mode": "wplata",
            "metal": metal,
            "krysztal": crystal,
            "deuter": deuterium,
        }
        url = Url.bank(planet.id)
        Game.SESSION.post(url, data)
        print("Deposit on", planet.name, "M:", metal, "C:", crystal, "D:", deuterium)

    @staticmethod
    def withdraw(planet, metal, crystal, deuterium):
        data = {
            "mode": "wyplata",
            "metal": metal,
            "krysztal": crystal,
            "deuter": deuterium,
        }
        url = Url.bank(planet.id)
        Game.SESSION.post(url, data)
        print("Withdrawal on", planet.name, "M:", metal, "C:", crystal, "D:", deuterium)

    @staticmethod
    def get_balance():
        response = Browser.go_to(Url.bank(Game.HOMEWORLD))
        result = re.findall("(?<=<\/th><th>)[0-9\.]*(?=<\/th)", response.text)
        balance = {
            "metal": result[0].replace(".", ""),
            "crystal": result[1].replace(".", ""),
            "deuterium": result[2].replace(".", ""),
        }
        return balance
