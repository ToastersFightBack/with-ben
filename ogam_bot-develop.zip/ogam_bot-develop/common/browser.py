import re
from config import ACCOUNT_DATA
from game import Game


class Browser:
    @staticmethod
    def login():
        data = {"username": ACCOUNT_DATA["login"], "password": ACCOUNT_DATA["password"]}
        url = ACCOUNT_DATA["uni_url"] + "login.php"
        response = Game.SESSION.post(url, data)

        Game.BASE_URL = "http://uni10.ogam.net.pl/index.php?page="
        Game.SESSION_ID = re.search('(?<=sin=).[^"]+', response.text)[0]
        for world in list(re.findall("(?<=cp=).[^&]+", response.text)):
            line = [line for line in response.text.split("\n") if world in line]
            Game.WORLDS[world] = re.search('(?<=re=0">)(.+?)(?=&)', line[0])[0]
            Game.COORDS[re.search("\[\d*:\d*:\d*\]", line[0])[0]] = world

    @staticmethod
    def go_to(url):
        return Game.SESSION.get(url)
