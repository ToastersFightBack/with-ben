from common.browser import Browser
from urls import Url
import re


class Research:
    TECHNOLOGIES = {
        "Technologia szpiegowska": 106,
        "Technologia komputerowa": 108,
        "Technologia bojowa": 109,
        "Technologia ochronna": 110,
        "Opancerzenie": 111,
        "Technologia energetyczna": 113,
        "Technologia nadprzestrzenna": 114,
        "Napęd spalinowy": 115,
        "Napęd impulsowy": 117,
        "Napęd nadprzestrzenny": 118,
        "Technologia laserowa": 120,
        "Technologia jonowa": 121,
        "Technologia plazmowa": 122,
        "Międzygalaktyczna Sieć Badań Naukowych": 123,
        "Technologia Ekspedycji": 124,
        "Rozwój grawitonów": 199,
    }

    TECHNOLOGIES_NAMES = dict(map(reversed, TECHNOLOGIES.items()))

    DESIRED_LEVELS = {
        106: 22,
        108: 20,
        109: 25,
        110: 25,
        111: 25,
        113: 20,
        114: 8,
        115: 20,
        117: 20,
        118: 20,
        120: 12,
        121: 5,
        122: 7,
        123: 20,
        124: 20,
        199: 1,
    }
    CURRENT_LEVELS = {}
    AVAILABLE = {}

    @staticmethod
    def get_current_levels():
        response = Browser.go_to(Url.research())
        for tech_name in Research.TECHNOLOGIES.keys():
            line = [line for line in response.text.split("\n") if tech_name in line]
            level = int(re.search("(?<=Poziom ).[^ ]*", line[0])[0]) if line else 0
            Research.CURRENT_LEVELS[Research.TECHNOLOGIES[tech_name]] = level

    @staticmethod
    def get_available():
        response = Browser.go_to(Url.research())
        for tech_name in Research.TECHNOLOGIES.keys():
            url = "&cmd=search&tech=" + str(Research.TECHNOLOGIES[tech_name]) + "&"
            available = True if url in response.text else False
            Research.AVAILABLE[Research.TECHNOLOGIES[tech_name]] = available

    @staticmethod
    def start_research(research):
        Browser.go_to(Url.start_research(research))
        print(
            "Researching",
            Research.TECHNOLOGIES_NAMES[research],
            Research.CURRENT_LEVELS[research] + 1,
        )

    @staticmethod
    def select_research():
        Research.get_current_levels()
        Research.get_available()
        for research in Research.AVAILABLE.keys():
            if (
                Research.CURRENT_LEVELS[research] < Research.DESIRED_LEVELS[research]
                and Research.AVAILABLE[research]
            ):
                Research.start_research(research)
                return
