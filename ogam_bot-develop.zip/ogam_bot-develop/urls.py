from game import Game
from config import ACCOUNT_DATA
from common.browser import Browser


class Url:
    @staticmethod
    def overview(planet):
        return Game.BASE_URL + "overview&sin=" + Game.SESSION_ID + "&cp=" + planet

    @staticmethod
    def empire():
        return Game.BASE_URL + "imperium&sin=" + Game.SESSION_ID + "&mode=&re=0"

    @staticmethod
    def buildings(planet):
        return (
            Game.BASE_URL
            + "buildings&sin="
            + Game.SESSION_ID
            + "&cp="
            + planet
            + "&mode=&re=0"
        )

    @staticmethod
    def research():
        return (
            Game.BASE_URL
            + "buildings&sin="
            + Game.SESSION_ID
            + "&cp="
            + Game.HOMEWORLD
            + "&mode=research&re=0"
        )

    @staticmethod
    def shipyard(planet):
        return (
            Game.BASE_URL
            + "buildings&mode=fleet&sin="
            + Game.SESSION_ID
            + "&cp="
            + planet
            + "&mode=fleet&re=0"
        )

    @staticmethod
    def defense(planet):
        return (
            Game.BASE_URL
            + "buildings&sin="
            + Game.SESSION_ID
            + "&cp="
            + planet
            + "&mode=defense&re=0"
        )

    @staticmethod
    def fleet(planet):
        return (
            Game.BASE_URL
            + "fleet&sin="
            + Game.SESSION_ID
            + "&cp="
            + planet
            + "&mode=&re=0"
        )

    @staticmethod
    def disassembly(planet):
        return (
            Game.BASE_URL
            + "demontownia&sin="
            + Game.SESSION_ID
            + "&cp="
            + planet
            + "&mode=&re=0"
        )

    @staticmethod
    def merchant(planet):
        return (
            Game.BASE_URL
            + "merchand&sin="
            + Game.SESSION_ID
            + "&cp="
            + planet
            + "&mode=&re=0"
        )

    @staticmethod
    def bank(planet):
        return (
            Game.BASE_URL
            + "bankacc&sin="
            + Game.SESSION_ID
            + "&cp="
            + planet
            + "&mode=&re=0"
        )

    @staticmethod
    def start_research(research):
        research = str(research)
        Browser.go_to(Url.research())
        return (
            Game.BASE_URL
            + "buildings&mode=research&cmd=search&tech="
            + research
            + "&sin="
            + Game.SESSION_ID
        )

    @staticmethod
    def start_build(planet, building):
        planet = str(planet)
        building = str(building)
        Browser.go_to(Url.buildings(planet))
        return (
            Game.BASE_URL
            + "buildings&action=insert&build="
            + building
            + "&sin="
            + Game.SESSION_ID
        )

    @staticmethod
    def small_shield():
        return ACCOUNT_DATA.get("uni_url") + "nowaobrona.php?mode=malapowloka&sin=" + Game.SESSION_ID

    @staticmethod
    def large_shield():
        return ACCOUNT_DATA.get("uni_url") + "nowaobrona.php?mode=duzapowloka&sin=" + Game.SESSION_ID
