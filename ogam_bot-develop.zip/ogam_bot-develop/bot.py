from common.browser import Browser
from game import Game
from models.planet import Planet
from pathlib import Path
import loop
import datetime
import logging
import time

logs_path = Path.cwd().joinpath("logs", "error.log")
logs_path.parent.mkdir(parents=True, exist_ok=True)
logs_path.touch(exist_ok=True)

logging.basicConfig(
    filename=logs_path,
    level=logging.ERROR,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger(__name__)

Browser.login()
planets = [Planet(planet_id) for planet_id in Game.WORLDS.keys()]

for planet in planets:
    if planet.is_homeworld:
        Game.HOMEWORLD = planet.id

loop_num = 0

while True:
    try:
        loop_num += 1
        loop.main_loop(planets, loop_num)
    except Exception as e:
        logger.exception(e)
        if str(e) == "SessionInvalid":
            print("Session invalid, logging in again ...")
            Browser.login()
        else:
            print(
                "Error occurred at",
                datetime.datetime.now(),
                "restarting loop in 10 s...",
            )
            time.sleep(10)
