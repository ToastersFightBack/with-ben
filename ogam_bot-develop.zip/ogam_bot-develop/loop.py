from common.bank import Bank
from common.research import Research
from common.browser import Browser
from common.overview import Overview
from urls import Url
import time
import random


def main_loop(planets, loop_num):
    print("--- STARTING LOOP", loop_num, "---")
    start = time.perf_counter()
    is_session_valid()
    being_attacked = Overview.planets_under_attack()

    if loop_num % 10:
        Research.select_research()

    for planet in planets:
        if loop_num % 10:
            planet.buildings.select_building()
            planet.resources.auto_exchange()

        magazines = planet.buildings.get_full_magazines()
        if planet.id in being_attacked:
            print(planet.name, "is under attack")
        if (
            all(magazine is True for magazine in magazines.values())
            and not planet.is_moon
        ) or planet.id in being_attacked:
            resources = planet.buildings.get_resources()
            Bank.deposit(
                planet,
                metal=resources["metal"],
                crystal=resources["crystal"],
                deuterium=resources["deuterium"],
            )
        if not planet.is_moon and loop_num % 100 == 0:
            planet.defense.build_defenses()

    sleep_duration = random.randint(10, 20)
    print(
        "--- LOOP FINISHED IN",
        round(time.perf_counter() - start, 2),
        "s, SLEEPING FOR",
        sleep_duration,
        "s ---",
    )
    time.sleep(sleep_duration)


def is_session_valid():
    response = Browser.go_to(Url.empire()).text
    if "Sesja niewazna, zaloguj sie ponownie !" in response:
        raise Exception("SessionInvalid")
    elif "Podgląd imperium" not in response:
        raise Exception("Unknown response")
