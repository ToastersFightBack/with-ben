from common.browser import Browser
from game import Game
from urls import Url
import re


class Defense:
    def __init__(self, planet):
        self.planet = planet
        self.structures = {}

    names = {
        "Wyrzutnia rakiet": "wr",
        "Lekkie działo laserowe": "ldl",
        "Ciężkie działo laserowe": "cdl",
        "Działo Gaussa": "dg",
        "Działo jonowe": "dj",
        "Wyrzutnia plazmy": "wp",
        "Przeciwrakieta": "prz",
        "Rakieta międzyplanetarna": "rmp"
    }

    names_reversed = dict(map(reversed, names.items()))

    desired = {
        "wr": 100000,
        "ldl": 100000,
        "cdl": 10000,
        "dg": 1000,
        "dj": 10000,
        "wp": 1000,
        "prz": 1000000,
        "rmp": 0
    }

    def get_defense(self):
        response = Browser.go_to(Url.defense(self.planet.id))
        for structure in self.names.keys():
            line = [
                line
                for line in response.text.split("\n")
                if structure + "</a> " in line
            ]
            if line:
                self.structures[self.names[structure]] = int(re.search('(?<=\(dostępnych <\/u>: ).*(?=\))', line[0])[0].replace('.', ''))

    def build(self, structure, amount):
        data = {
            "mode": "addit",
            "sin": Game.SESSION_ID,
            "wr": 0,
            "ldl": 0,
            "cdl": 0,
            "dg": 0,
            "dj": 0,
            "wp": 0,
            "prz": 0,
            "rmp": 0
        }
        Browser.go_to(Url.defense(self.planet.id))
        url = "http://uni10.ogam.net.pl/nowaobrona.php?sin=" + Game.SESSION_ID
        data[structure] = amount
        Game.SESSION.post(url, data)
        print("Defense", amount, self.names_reversed[structure], "on", self.planet.name)

    def rebuild(self):
        data = {
            "mode": "addit",
            "sin": Game.SESSION_ID,
            "wr": 0,
            "ldl": 0,
            "cdl": 0,
            "dg": 0,
            "dj": 0,
            "wp": 0,
            "prz": 0,
            "rmp": 0
        }
        Browser.go_to(Url.defense(self.planet.id))
        url = "http://uni10.ogam.net.pl/nowaobrona.php?sin=" + Game.SESSION_ID
        build = False
        for structure in self.structures.keys():
            if self.desired[structure] - self.structures[structure] > 0:
                build = True
                data[structure] = structure, self.desired[structure] - self.structures[structure]
        if build:
            Game.SESSION.post(url, data)
            print("Defense rebuilt on", self.planet.name)

    def build_shields(self):
        response = Browser.go_to(Url.defense(self.planet.id))
        if "Zbuduj małą powłokę" in response.text:
            Browser.go_to(Url.small_shield())
            print("Small shield built on", self.planet.name)
        if "Zbuduj dużą powłokę" in response.text:
            Browser.go_to(Url.large_shield())
            print("Large shield built on", self.planet.name)

    def build_defenses(self):
        self.get_defense()
        self.build_shields()
        self.rebuild()

    class structure:
        wyrzutnia_rakiet = "wr",
        lekkie_dzialo_laserowe = "ldl",
        ciezkie_dzialo_laserowe = "cdl",
        dzialo_gaussa = "dg",
        dzialo_jonowe = "dj",
        wyrzutnia_plazmy = "wp",
        przeciwrakieta = "prz",
        rakieta_miedzyplnetarna = "rmp"
