from game import Game
from models.building import Buildings
from models.merchant import Merchant
from models.shipyard import Shipyard
from models.defense import Defense


class Planet:
    def __init__(self, id):
        self.id = id
        self.name = Game.WORLDS[self.id]
        self.is_moon = "Moon" in self.name
        self.is_homeworld = "1" == self.name

        self.buildings = Buildings(self)
        self.shipyard = Shipyard(self)
        self.resources = Merchant(self)
        self.defense = Defense(self)
