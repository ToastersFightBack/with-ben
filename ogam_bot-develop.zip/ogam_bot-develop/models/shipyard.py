from common.browser import Browser
from game import Game
from urls import Url


class Shipyard:
    def __init__(self, planet):
        self.planet = planet

    names = {
        "Mały transporter": "malyt",
        "Duży transporter": "duzyt",
        "Lekki myśliwiec": "lm",
        "Ciężki myśliwiec": "cm",
        "Krążownik": "kraz",
        "Okręt wojenny": "ow",
        "Statek kolonizacyjny": "kolo",
        "Recykler": "rec",
        "Sonda szpiegowska": "sonda",
        "Bombowiec": "bomb",
        "Satelita słoneczny": "sat",
        "Niszczyciel": "nisz",
        "Gwiazda Śmierci": "gs",
        "Pancernik": "panc",
        "Fleet Slov": "ft",
        "Ultra transporter": "ut",
        "Aurora": "ar",
        "Szperacz": "szp",
    }

    ships = {
        "malyt": 0,
        "duzyt": 0,
        "lm": 0,
        "cm": 0,
        "kraz": 0,
        "ow": 0,
        "kolo": 0,
        "rec": 0,
        "sonda": 0,
        "bomb": 0,
        "sat": 0,
        "nisz": 0,
        "gs": 0,
        "panc": 0,
        "ft": 0,
        "ut": 0,
        "ar": 0,
        "szp": 0,
    }

    def build(self, ship, amount):
        data = {
            "mode": "addit",
            "sin": Game.SESSION_ID,
            "malyt": 0,
            "duzyt": 0,
            "lm": 0,
            "cm": 0,
            "kraz": 0,
            "ow": 0,
            "kolo": 0,
            "rec": 0,
            "sonda": 0,
            "bomb": 0,
            "sat": 0,
            "nisz": 0,
            "gs": 0,
            "panc": 0,
            "ft": 0,
            "ut": 0,
            "ar": 0,
            "szp": 0,
        }
        Browser.go_to(Url.shipyard(self.planet.id))
        url = "http://uni10.ogam.net.pl/nowastocznia.php?sin=" + Game.SESSION_ID
        data[ship] = amount
        Game.SESSION.post(url, data)
        print("Shipyard", amount, ship, "on", self.planet.name)

    class ship:
        maly_transporter = "malyt"
        duzy_transporter = "duzyt"
        lekki_mysliwiec = "lm"
        ciezki_mysliwiec = "cm"
        krazownik = "kraz"
        okret_wojenny = "ow"
        statek_kolonizacyjny = "kolo"
        recykler = "rec"
        sonda_szpiegowska = "sonda"
        bombowiec = "bomb"
        satelita_sloneczny = "sat"
        niszczyciel = "nisz"
        gwiazda_smierci = "gs"
        pancernik = "panc"
        fleet_slov = "ft"
        ultra_transporter = "ut"
        aurora = "ar"
        szperacz = "szp"
