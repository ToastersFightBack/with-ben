from common.browser import Browser
from urls import Url
import math
import re


class Buildings:
    def __init__(self, planet):
        self.planet = planet
        self.response = Browser.go_to(Url.buildings(planet.id))
        self.current_levels = {}
        self.available = {}

    BULDINGS = {
        "Kopalnia metalu": 1,
        "Kopalnia kryształu": 2,
        "Ekstraktor deuteru": 3,
        "Elektrownia słoneczna": 4,
        "Fabryka robotów": 14,
        "Fabryka nanitów": 15,
        "Stocznia": 21,
        "Magazyn metalu": 22,
        "Magazyn kryształu": 23,
        "Zbiornik deuteru": 24,
        "Laboratorium badawcze": 31,
        "Terraformer": 33,
        "Depozyt sojuszniczy": 34,
        "Stacja księżycowa": 41,
        "Falanga czujników": 42,
        "Teleporter": 43,
        "Silos rakietowy": 44,
    }

    BULDING_NAMES = dict(map(reversed, BULDINGS.items()))

    DESIRED_LEVELS = {
        1: 100,
        2: 100,
        3: 100,
        4: 15,
        14: 27,
        15: 17,
        21: 22,
        22: 0,
        23: 0,
        24: 0,
        31: 25,
        33: 0,
        34: 15,
        41: 20,
        42: 0,
        43: 0,
        44: 15,
    }

    def get_current_levels(self):
        for building_name in self.BULDINGS.keys():
            line = [
                line
                for line in self.response.text.split("\n")
                if building_name + " (Poziom" in line
            ]
            level_string = (
                re.search("(?<=Poziom )[0-9]*(?=\)<\/a)", line[-1])
                if len(line)
                else None
            )
            level = int(level_string[0]) if level_string else 0
            self.current_levels[self.BULDINGS[building_name]] = level

    def get_available(self):
        for building_name in self.BULDINGS.keys():
            url = "&action=insert&build=" + str(self.BULDINGS[building_name]) + "&"
            available = True if url in self.response.text else False
            self.available[self.BULDINGS[building_name]] = available

    def get_full_magazines(self):
        magazines = {22: False, 23: False, 24: False}
        lines = [
            line for line in self.response.text.split("\n") if "Magazyn pełny" in line
        ]

        for line in lines:
            if "Metal" in line:
                magazines[22] = True
            if "Kryształ" in line:
                magazines[23] = True
            if "Deuter" in line:
                magazines[24] = True
        return magazines

    def get_resources(self):
        resources = {}
        resources_strings = re.findall(
            '(?<=width="125">)(.*)(?= <br)', self.response.text
        )
        resources_strings = [
            int(
                value.replace(".", "")
                .replace('<font color="#ff0000">', "")
                .replace("</font>", "")
                .replace("--------", "0")
            )
            for value in resources_strings
        ]

        if len(resources_strings) >= 3:
            resources["metal"] = resources_strings[0]
            resources["crystal"] = resources_strings[1]
            resources["deuterium"] = resources_strings[2]
            resources["energy"] = resources_strings[3]

        return resources

    def get_free_space(self):
        regex_result = re.search("(?<= Pozostało )(.*)(?= pól)", self.response.text)
        free_space = int(regex_result[0] if regex_result else "-1")
        return free_space

    def is_building_in_queue(self, building):
        string = (
            self.BULDING_NAMES[building]
            + " (Poziom "
            + str(self.current_levels[building] + 1)
            + ")"
        )
        return string in self.response.text

    def build_energy(self, resources):
        if resources.get("energy", 0) < 0:
            sat_num = math.ceil(-resources["energy"] / 1500)
            self.planet.shipyard.build(
                self.planet.shipyard.ship.satelita_sloneczny, sat_num
            )

    def build(self, building):
        Browser.go_to(Url.buildings(self.planet.id))
        self.response = Browser.go_to(Url.start_build(self.planet.id, building))
        print(
            "Building",
            self.BULDING_NAMES[building],
            self.current_levels[building] + 1,
            "on",
            self.planet.name,
        )
        self.get_available()

    def select_building(self):
        self.response = Browser.go_to(Url.buildings(self.planet.id))
        resources = self.get_resources()

        self.build_energy(resources)

        self.get_current_levels()
        self.get_available()
        magazines = self.get_full_magazines()

        if 0 <= self.get_free_space() < 3:
            if self.available.get(33):
                self.build(33)
            elif self.available.get(41):
                self.build(41)
            else:
                print(
                    self.planet.name,
                    "has no free space and not enough resources to expand",
                )
                return

        for building in self.DESIRED_LEVELS.keys():
            self.is_building_in_queue(building)
            if (
                self.DESIRED_LEVELS[building] > self.current_levels[building]
                and self.available[building]
                and not self.is_building_in_queue(building)
            ):
                self.build(building)

        for magazine in magazines.keys():
            if magazines[magazine]:
                if (
                    self.available[magazine]
                    and not self.is_building_in_queue(magazine)
                    and not self.planet.is_moon
                ):
                    self.build(magazine)
        self.response = Browser.go_to(Url.buildings(self.planet.id))
