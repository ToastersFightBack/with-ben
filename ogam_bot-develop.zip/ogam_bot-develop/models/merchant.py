from common.browser import Browser
from game import Game
from urls import Url
import math


class Merchant:
    def __init__(self, planet):
        self.planet = planet

    def exchange_metal(self, amount):
        choice = 4
        self.merchant_exchange(choice, amount)

    def exchange_crystal(self, amount):
        choice = 5
        self.merchant_exchange(choice, amount)

    def exchange_deuterium(self, amount):
        choice = 6
        self.merchant_exchange(choice, amount)

    def merchant_exchange(self, choice, amount, action=2):
        data = {
            "action": action,
            "proporcjametal": 4,
            "proporcjakrysztal": 2,
            "proporcjadeuter": 1,
        }
        resource = ""

        if choice == 4:
            resource = "metal"
            data[resource] = amount
        elif choice == 5:
            resource = "krysztal"
            data[resource] = amount
        elif choice == 6:
            resource = "deuter"
            data[resource] = amount

        Browser.go_to(Url.merchant(self.planet.id))
        data["choix"] = choice
        url = "http://uni10.ogam.net.pl/index.php?page=marchand&sin=" + Game.SESSION_ID
        Game.SESSION.post(url, data)
        print("Exchanging", amount, resource, "on", self.planet.name)

    def auto_exchange(self):
        if self.planet.is_moon:
            return

        magazines = self.planet.buildings.get_full_magazines()
        resources = self.planet.buildings.get_resources()
        for magazine in magazines:
            if magazines[magazine]:
                if magazine == 22:
                    amount = math.floor(resources["metal"] * 0.1)
                    self.exchange_metal(amount)
                if magazine == 23:
                    amount = math.floor(resources["crystal"] * 0.1)
                    self.exchange_crystal(amount)
                if magazine == 24:
                    amount = math.floor(resources["deuterium"] * 0.1)
                    self.exchange_deuterium(amount)
